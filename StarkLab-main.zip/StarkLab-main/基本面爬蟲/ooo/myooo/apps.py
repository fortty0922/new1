from django.apps import AppConfig


class MyoooConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "myooo"
